<?php 

session_start();