<?php

include('includes/config.php');
include('includes/database.php');
include('includes/functions.php');
secure();

include('includes/header.php');

if (isset($_GET['delete'])) {
    // Delete user if delete parameter is set
    $deleteId = $_GET['delete'];
    $stm = $pdo->prepare('DELETE FROM users WHERE id = ?');

    if ($stm) {
        $stm->bindValue(1, $deleteId, PDO::PARAM_INT);
        $stm->execute();

        set_message("User with ID {$deleteId} has been deleted");
        header('Location: users.php');
        exit();
    } else {
        echo 'Could not prepare delete statement!';
    }
}

if ($stm = $pdo->prepare('SELECT * FROM users')){
    $stm->execute();


    $result = $stm->fetchAll(PDO::FETCH_ASSOC);


    
    if ($result){
  


?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <h1 class="display-1">Users management</h1>
        <table id="example2" class="table table-striped table-hover" style="width:100%">
        <thead>
        <tr>
            <th>Id</th>
            <th>Username</th>
            <th>Email</th>
            <th>Status</th>
            <th>Edit | Delete</th>

         </tr>
         </thead>
         <tbody>


         <?php foreach ($result as $record) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['id']); ?> </td>
                                <td><?php echo htmlspecialchars($record['username']); ?> </td>
                                <td><?php echo htmlspecialchars($record['email']); ?> </td>
                                <td><?php echo htmlspecialchars($record['active']); ?> </td>
                                <td>
                                    <a href="users_edit.php?id=<?php echo htmlspecialchars($record['id']); ?>">Edit</a> |
                                    <a href="users.php?delete=<?php echo htmlspecialchars($record['id']); ?>">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>

                    </table>

                    <a href="users_add.php"> Add new user</a>

                </div>
            </div>
        </div>
        
<script>
 new DataTable('#example2');

 </script>
<?php
   } else 
   {
    echo 'No users found';
   }

    
   $stm->closeCursor();

} else {
   echo 'Could not prepare statement!';
}
include('includes/footer.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link href="bootstrap-4.0.0-dist/css/bootstrap.css" rel="stylesheet">
    <link href="DataTables/datatables.css" rel="stylesheet">
    <script src="bootstrap-4.0.0-dist/js/bootstrap.js"></script>
    <script src="jquery-3.7.1.min.js"></script>
<script src="DataTables/datatables.js"></script>


    <title>SIR Bulletin User CMS</title>
</head>
<body>
</body>

</html>